import Button from '@mui/material/Button';

export default function ButtonBasic() {
  return (
    <div>
        <Button size="small" variant='outlined'>Small</Button>
        <Button size="large" variant='contained'>Big</Button>
    </div>
    
  ) 

}