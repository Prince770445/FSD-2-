// Textfield.jsx
import TextField from "@mui/material/TextField";

function Textfield({ label, value, onChange, type = "text", error, helperText }) {
  return (
    <TextField
      label={label}
      value={value}
      onChange={onChange}
      type={type}
      error={error}
      helperText={helperText}
      fullWidth
      margin="normal"
      variant="outlined"
    />
  );
}

export default Textfield;
