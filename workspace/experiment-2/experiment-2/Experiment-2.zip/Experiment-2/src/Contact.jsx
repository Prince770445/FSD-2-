import Textfield
 from "./components/Textfield";

export default function Contact() {
  return <div>
    <h2>Contact Form</h2>
    <Textfield/>
  </div>
}