import ButtonBasic from "./components/Button";


export default function About() {
  return <div>
    <h2>About Page</h2>
    <ButtonBasic/>
  </div>

}